package com.example.mobileapplicationassignment1;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
//imports of the needed packages

public class MainActivity extends AppCompatActivity {

    private EditText mortgageAmount, interestRate, tenure;
    private Button calculateButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mortgageAmount = findViewById(R.id.mortgageAmount);
        interestRate = findViewById(R.id.interestRate);
        tenure = findViewById(R.id.tenure);
        calculateButton = findViewById(R.id.calculateButton);


        //set the onTouchlisteners for the functionality of the events.
        mortgageAmount.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                v.requestFocus();
                showKeyboard(v);
            }
            return false;
        });

        //set the onTouchlisteners for interest rate
        interestRate.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                v.requestFocus();
                showKeyboard(v);
            }
            return false;
        });

        //set the onTouchlisteners for tenure years
        tenure.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                v.requestFocus();
                showKeyboard(v);
            }
            return false;
        });

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //initializes the mortgage, interest rate and tenure years utilizing strings.
                String amount = mortgageAmount.getText().toString();
                String rate = interestRate.getText().toString();
                String time = tenure.getText().toString();

                //intent in order to make values provided functional, to EMI Calculation activity
                Intent intent = new Intent(MainActivity.this, EMICalculation.class);
                intent.putExtra("amount", amount);
                intent.putExtra("rate", rate);
                intent.putExtra("time", time);
                startActivity(intent);

                //hides the keyboard when the button is clicked, not needed though.
                hideKeyboard();
            }
        });
    }

    //method utilized to show the keyboard (not needed, serves as creative interest)
    private void showKeyboard(View view) {
        if (view.requestFocus()) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT);
        }
    }

    //method utilized to hide the keyboard (not needed, serves as creative interest)
    private void hideKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
}
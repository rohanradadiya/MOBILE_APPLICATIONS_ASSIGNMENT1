package com.example.mobileapplicationassignment1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class EMICalculation extends AppCompatActivity {

    //for the EMI calculation and the "Back" buttons
    private TextView emiResult;
    private Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emicalculation);

        emiResult = findViewById(R.id.emiResult);
        backButton = findViewById(R.id.backButton);

        //retrieves the inputs passed from the MainActivity
        String amountStr = getIntent().getStringExtra("amount");
        String rateStr = getIntent().getStringExtra("rate");
        String timeStr = getIntent().getStringExtra("time");

        //converts the strings to numeric types, with the necessary calculations required.
        double amount = Double.parseDouble(amountStr);
        double rate = Double.parseDouble(rateStr) / 12 / 100;  // Monthly interest rate
        int time = Integer.parseInt(timeStr) * 12;  // Convert years to months

        //EMI calculation formula: P * r * (1 + r)^n / [(1 + r)^n - 1]. Used to calculate the overall EMI.
        double emi = (amount * rate * Math.pow(1+rate, time)) / (Math.pow(1+rate, time)-1);

        //portrays the calculated EMI, based on the values provided by the user.
        emiResult.setText(String.format("Your EMI according to the values provided is: %.3f", emi));

        //"Back" button in order to return to the page before. Also known as the activity before.
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                //finishes the current activity and return to MainActivity
            }
        });
    }
}
